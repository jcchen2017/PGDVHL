function [fs, cs, H, A, X0, B, y] = getSignals_bdft_withsep(r, s, n)

fs = rand(r,1);

if r == 1
    sep = 1;
else
    fs_sort = sort(fs);
    sep = min(min(abs(fs_sort(2:end)-fs_sort(1:end-1))),fs_sort(1)+1-fs_sort(end));
end

while(sep<1/n)
    fs = rand(r,1);
    if r == 1
        sep = 1;
    else
        fs_sort = sort(fs);
        sep = min(min(abs(fs_sort(2:end)-fs_sort(1:end-1))),fs_sort(1)+1-fs_sort(end));
    end
end

dynamic_range= 20;
cs = exp(-1i*2*pi*rand(r,1)) .* (1 + 10.^(rand(r,1).*(dynamic_range/20)));

Cs = diag(cs); %J x J diag matrix

H = zeros(s, r);
for kk = 1:r
    H(:,kk) = randn(s,1);
    H(:,kk) = H(:, kk)/norm(H(:,kk));
end

A = zeros(r, n);
for kk  = 1:r
    tmp = amplitude(fs(kk), n);
    A(kk,:) = tmp';
end
X0 = H * Cs * A;



% get the observation

% Fourier samples
F = fft(eye(s));
B = zeros(n,s);
for i = 1 : n
    B(i,:) = F(randi(s),:);
end


y = zeros(n,1);

for i = 1:n
    y(i,1) =  B(i,:) * X0(:,i);
end

end

%%
function a = amplitude(fs, n)
N = 0:1:n-1;
a = exp(1i*2*pi*fs.*N);
end
