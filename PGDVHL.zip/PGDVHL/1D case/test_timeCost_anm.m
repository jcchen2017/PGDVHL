% ANM 
clear all;clc

avg_times = 10;
n1 = 512; % n=54, 128, 256

s = 3;
r = 3;
time_cost =zeros(avg_times,1);
err_anm1 = zeros(avg_times,1);

for ii = 1:avg_times
    [fs1, ~, ~, ~, X01, B1, y1] = getSignals_bdft_withsep(r, s, n1);
    
    tic;
    X_anm1 = solverANM(y1, B1);
    t_anm1 = toc;
    time_cost(ii,1) = t_anm1;
    err_anm1(ii,1) = norm(X_anm1(:) - X01(:))/norm(X01(:));
    
    
    fprintf('anm Time: %f\t Error: %f\n', t_anm1, err_anm1(ii));
end

    
