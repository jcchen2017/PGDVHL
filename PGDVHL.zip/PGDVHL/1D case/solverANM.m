function X = solverANM(y, B)
% ANM solver

[n, s] = size(B);


cvx_solver sdpt3
cvx_begin sdp quiet
    cvx_precision best
    
    variable X(s,n) complex;
    variable u1(1);
    variable u2(n-1) complex;
    variable T(s,s) hermitian;
   
    minimize 1/2*u1+1/2*trace(T)
    subject to
    
        % measurement
        for i = 1:n
            B(i,:) * X(:,i) == y(i);
        end
        
        % vector contraints
        u1(1) == (u1(1))'; % u(1) is real
        
        % positive semidefinite
        [toeplitz([u1;u2]) X'; X T] >= 0;
cvx_end

