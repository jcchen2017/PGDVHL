function [X] = solverHankel(y, B)
% low rank Hankel solver

[n, s] = size(B);
if mod(n,2) == 0
    n1 = n/2;
else
    n1 = (n+1)/2;
end
n2 = n+1 - n1;

%cvx_solver sdpt3
cvx_begin sdp quiet
    cvx_precision best

    variable X(s,n) complex;
    variable obj(s*n1, n2) complex;
    variable Q1(s*n1,s*n1) hermitian;
    variable Q2(n2,n2) hermitian;
        
    
    minimize 0.5*trace(Q1)+0.5*trace(Q2);
    subject to
        % measurement
        for ii = 1:n
            B(ii,:) * X(:,ii) == y(ii);
        end
        %y == diag(B*X);
        % hankel
        for ji = 1:n1
            for j2 = 1:n2
                row_idx = (ji-1)*s+1:ji*s;
                obj(row_idx, j2) == X(:, ji+j2-1);
            end
        end
        
        [Q1 obj; obj' Q2] >= 0;
        
cvx_end
end
