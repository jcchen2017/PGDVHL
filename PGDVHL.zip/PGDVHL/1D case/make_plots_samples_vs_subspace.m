clear all; close all;


%load('empir_probs_mat_pgd.mat')
load('empir_prob_mat_pgd_samples_vs_subspace.mat')

tmpPGD = empir_prob_mat_pgd_samples_vs_subspace(1:19,2:9);

figure(1)
colormap(gray);
imagesc(tmpPGD);
title('PGD-VHL','interpreter','latex','fontsize', fontsz)
ylabel('Number of samples: $n$','interpreter','latex','fontsize', fontsz)
xlabel('Dimension of subspace: $s$','interpreter','latex','fontsize', fontsz)
set(gca,'YDir','normal') % y��̶�����Ϊ��������һ������
set(gca, 'ytick',[1:1:19],'yticklabel',[8:4:80],'xtick',[1:1:8], 'xticklabel', [2:1:9],'xticklabelmode','manual','yticklabelmode','manual');
cbar = colorbar;
set(cbar,'Ticks',[0:0.2:1]);
%ax = gca;
%ax.YDir = 'normal';
hold on
x = 0:0.01:9;
y = 2.5*x;
plot(x,y,'red','Linewidth', 2);
% save pdf
myfig = gcf;
myfig.PaperUnits = 'inches';
myfig.PaperSize = [6 5.5];
myfig.PaperPosition = [0 0 6 5];
myfig.PaperPositionMode = 'manual';
figname = 'bdft_pgdvhl_samples_n880_vs_subspace_s29_withredline';
print( myfig, figname, '-depsc' );
%fprintf('freq err %f\n',hausdorff( fs_rec', fs) );



