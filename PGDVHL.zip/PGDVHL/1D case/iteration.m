%%%%Iteration%%%%
%% fix s 
n1 = 1024;
s = 4;
r = 4;
[fs1, ~, ~, ~, X01, B1, y1] = getSignals_bdft_withsep(r, s, n1);
[~,~,~,~,~,~,~,~,~,cond1,err1] = solverPgd_test1(y1,B1,n1,r,s,300,1/4,0,1,X01);


n2 = 1024;
s = 4;
r = 6;
[fs2, ~, ~, ~, X02, B2, y2] = getSignals_bdft_withsep(r, s, n2);
[~,~,~,~,~,~,~,~,~,cond2,err2] = solverPgd_test1(y2,B2,n2,r,s,300,1/4,0,1,X02);


n3 = 1024;
s = 4;
r = 8;
[fs3, ~, ~, ~, X03, B3, y3] = getSignals_bdft_withsep(r, s, n3);
[~,~,~,~,~,~,~,~,~,cond3,err3] = solverPgd_test1(y3,B3,n3,r,s,300,1/4,0,1,X03);

err_s = [err1, err2, err3];
load('err_s.mat')
err1 = err_s(:,1);
err2 = err_s(:,2);
err3 = err_s(:,3);

it = 1:300;
fontsz = 18;
plot(it,log(err1),'-','LineWidth', 1.5, 'Color', [240, 183, 26]/255);
hold on
plot(it,log(err2),'--','LineWidth', 1.5, 'Color', [242, 47, 12]/255);
plot(it,log(err3),'-.','LineWidth', 1.5,'Color', [50, 12, 242]/255);

grid on
set(gca,'ytick', -32:4:0, 'xtick', 0:50:300)
title('$n = 1024$, $s = 4$','interpreter','latex','fontsize', fontsz);
xlabel('Iteration','interpreter','latex','fontsize', fontsz);
ylabel('Log of reconstruction error','interpreter','latex','fontsize', fontsz);
legend({'$r=4$','$r=6$','$r=8$'},'interpreter','latex','FontSize',14);

% save pdf
myfig = gcf;
myfig.PaperUnits = 'inches';
myfig.PaperSize = [6 5.5];
myfig.PaperPosition = [0 0 6 5];
myfig.PaperPositionMode = 'manual';
figname = 'convergence_rate_fixs';
print( myfig, figname, '-depsc' );

save('err_s.mat','err_s');

%fix r
n4 = 1024;
s = 4;
r = 4;
[fs4, ~, ~, ~, X04, B4, y4] = getSignals_bdft_withsep(r, s, n4);
[~,~,~,~,~,~,~,~,~,cond4,err4] = solverPgd_test1(y4,B4,n4,r,s,300,1/4,0,1,X04);


n5 = 1024;
s = 6;
r = 4;
[fs5, ~, ~, ~, X05, B5, y5] = getSignals_bdft_withsep(r, s, n5);
[~,~,~,~,~,~,~,~,~,cond5,err5] = solverPgd_test1(y5,B5,n5,r,s,300,1/4,0,1,X05);


n6 = 1024;
s = 8;
r = 4;
[fs6, ~, ~, ~, X06, B6, y6] = getSignals_bdft_withsep(r, s, n6);
[~,~,~,~,~,~,~,~,~,cond6,err6] = solverPgd_test1(y6,B6,n6,r,s,300,1/4,0,1,X06);

err_r = [err4, err5, err6];
load('err_r.mat')
err4 = err_r(:,1);
err5 = err_r(:,2);
err6 = err_r(:,3);

it = 1:1:300;
fontsz = 18;
plot(it,log(err4),'-','LineWidth', 1.5, 'Color', [240, 183, 26]/255);
hold on
plot(it,log(err5),'--','LineWidth', 1.5, 'Color', [242, 47, 12]/255);
plot(it,log(err6),'-.','LineWidth', 1.5,'Color', [50, 12, 242]/255);

grid on
set(gca,'ytick',[-32:4:0],'xtick', [0:50:300],'ylim',[-35,0])
title('$n = 1024$, $r = 4$','interpreter','latex','fontsize', fontsz);
xlabel('Iteration','interpreter','latex','fontsize', fontsz);
ylabel('Log of reconstruction error','interpreter','latex','fontsize', fontsz);
legend({'$s=4$','$s=6$','$s=8$'},'interpreter','latex','FontSize',14);

% save pdf
myfig = gcf;
myfig.PaperUnits = 'inches';
myfig.PaperSize = [6 5.5];
myfig.PaperPosition = [0 0 6 5];
myfig.PaperPositionMode = 'manual';
figname = 'convergence_rate_fixr';
print( myfig, figname, '-depsc' );

save('err_r.mat','err_r');

