clear all;
close all

n = 8:4:96;
%s = 1:1:18; % dimension of subspace
s = 4;
r = 1:9;  % the number of spikes

Ln = length(n);
Lr = length(r);
avg_times = 20;


empir_probs_mat_pgd_samples_vs_spikes = zeros(Ln, Lr);

for j1 = 1:Ln % begin of the loop of r
    for j2 = 1:Lr % begin of the loop of s
        
        is_success_pgd = 0;
        for avg_t = 1:avg_times % begin of the loop of ave_times tests for fixed r and s
            fprintf('Iteration: %d|%d, %d|%d, test: %d\n', j1,Ln,j2, Lr, avg_t);
            
            [fs, ~, ~, ~, X0, B, y] = getSignals_bdft_withoutsep(r(j2), s, n(j1));
            
            if j2 == 1
                sep = 1;
            else
                fs_sort = sort(fs);
                sep = min(abs(fs_sort(2:end)-fs_sort(1:end-1)));
            end
            
            % ------- solve by PGD ----------
            tic;
            [si,iter,X_pgd,ratio,fv,mg,step,~,~,cond,~] = solverPgd(y,B,n(j1),r(j2),s,5000,1/4,1e-7,1e-5,0,1,X0);
            t_pgd = toc;
            
            err_pgd = norm(X_pgd(:) - X0(:))/norm(X0(:));
            
            fname = ['transition_pgd_samples_vs_spikes' datestr(now,'yyyymmdd') '.txt'];
            fid = fopen(fname,'a');
            fprintf(fid,'PGD: N: %d, r: %d, s: %d, minium sep.: %.3f, relerr: %.3f, time: %.3f\n',n(j1),r(j2),s,sep,err_pgd,t_pgd);
            fclose(fid);
            
        
            if err_pgd <= 1e-3
                is_success_pgd = is_success_pgd + 1;
            end
        end
        
        empir_probs_mat_pgd_samples_vs_spikes(j1, j2) = is_success_pgd/avg_times;
        
        if empir_probs_mat_pgd_samples_vs_spikes(j1,j2) == 0 % check: should be max here to make both rates are zeros
            for j = j2+1:Lr
                empir_probs_mat_pgd_samples_vs_spikes(j1, j) = 0;
            end
            break; % break the loop of s if both rates are zeros
        end
                       
    end % the loop of s
end % the loop of r

save('empir_probs_mat_pgd_samples_vs_spikes.mat','empir_probs_mat_pgd_samples_vs_spikes')
