clear all;
close all

N = 64;
s = 1:1:18; % dimension of subspace
r = 1:1:18;  % the number of spikes

Ls = length(s);
Lr = length(r);
avg_times = 20;

empir_probs_mat_pgd_bdft_withsep = zeros(Lr, Ls);
empir_probs_mat_anm_bdft_withsep = zeros(Lr, Ls);
empir_probs_mat_hankel_bdft_withsep = zeros(Lr, Ls);

for j1 = 1:Lr % begin of the loop of r
    for j2 = 1:Ls % begin of the loop of s
        
        is_success_pgd = 0;
        is_success_anm = 0;
        is_success_hankel = 0;
        for avg_t = 1:avg_times % begin of the loop of ave_times tests for fixed r and s
            fprintf('Iteration: %d|%d, %d|%d, test: %d\n', j1,Lr,j2, Ls, avg_t);
            
            [fs, ~, ~, ~, X0, B, y] = getSignals_bdft_withsep(r(j1), s(j2), N);
            
            if j1 == 1
                sep = 1;
            else
                fs_sort = sort(fs);
                sep = min(abs(fs_sort(2:end)-fs_sort(1:end-1)));
            end
            
            % ------- solve by PGD ----------
            tic;
            [si,iter,X_pgd,ratio,fv,mg,step,~,~,cond,~] = solverPgd(y,B,N,r(j1),s(j2),5000,1/4,1e-7,1e-5,0,1,X0);
            t_pgd = toc;
            
            err_pgd = norm(X_pgd(:) - X0(:))/norm(X0(:));
            
            fname = ['transition_pgd_dft_withsep.txt'];
            fid = fopen(fname,'a');
            fprintf(fid,'PGD: N: %d, r: %d, s: %d, minium sep.: %.3f, relerr: %.3f, time: %.3f\n', N,r(j1),s(j2),sep, err_pgd,t_pgd);
            fclose(fid);
            
            if err_pgd <= 1e-3
                is_success_pgd = is_success_pgd + 1;
            end
            
            % ------- solve by Hankel ----------
            tic;
            X_hankel = solverHankel(y, B);
            t_hankel = toc;
            
            err_hankel = norm(X_hankel(:) - X0(:))/norm(X0(:));
            
            fname = ['transition_hankel_dft_withsep.txt'];
            fid = fopen(fname,'a');
            fprintf(fid,'Hankel: N: %d, r: %d, s: %d, minium sep.: %.3f, relerr: %.3f, time: %.3f\n', N,r(j1),s(j2),sep, err_hankel,t_hankel);
            fclose(fid);
            
        
            if err_hankel <= 1e-3
                is_success_hankel = is_success_hankel + 1;
            end
            
            % ------- solve by ANM ----------
            tic;
            X_anm = solverANM(y, B);
            t_anm = toc;
            
            err_anm = norm(X_anm(:) - X0(:))/norm(X0(:));
            
            fname = ['transition_anm_dft_withsep.txt'];
            fid = fopen(fname,'a');
            fprintf(fid,'ANM: N: %d, r: %d, s: %d, minium sep.: %.3f, relerr: %.3f, time: %.3f\n', N,r(j1),s(j2),sep, err_anm,t_anm);
            fclose(fid);
            
        
            if err_anm <= 1e-3
                is_success_anm = is_success_anm + 1;
            end
            
            
        end
        
        empir_probs_mat_pgd_bdft_withsep(j1, j2) = is_success_pgd/avg_times;
        empir_probs_mat_hankel_bdft_withsep(j1, j2) = is_success_hankel/avg_times;
        empir_probs_mat_anm_bdft_withsep(j1, j2) = is_success_anm/avg_times;
        
        if max(empir_probs_mat_pgd_bdft_withsep(j1,j2),empir_probs_mat_hankel_bdft_withsep(j1,j2),empir_probs_mat_anm_bdft_withsep(j1, j2)) == 0 % check: should be max here to make both rates are zeros
            for j = j2+1:Ls
                empir_probs_mat_pgd_bdft_withsep(j1, j) = 0;
                empir_probs_mat_hankel_bdft_withsep(j1, j) = 0;
                empir_probs_mat_anm_bdft_withsep(j1, j) = 0;
            end
            break; % break the loop of s if both rates are zeros
        end
                       
    end % the loop of s
end % the loop of r

save('empir_probs_mat_pgd_bdft_withsep.mat','empir_probs_mat_pgd_bdft_withsep')
save('empir_probs_mat_anm_bdft_withsep.mat','empir_probs_mat_anm_bdft_withsep')
save('empir_probs_mat_hankel_bdft_withsep.mat','empir_probs_mat_hankel_bdft_withsep')