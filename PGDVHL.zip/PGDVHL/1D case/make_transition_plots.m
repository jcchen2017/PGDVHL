clear all; close all;

fontsz = 16;

%load('empir_probs_mat_pgd.mat')
%load('empir_probs_mat_pgd_withsep.mat')

tmpPGD = zeros(11,18);
for i = 1 : 11
    tmpPGD(i,:) = empir_probs_mat_pgd_bdft_withoutsep(i,:);
end

figure(1)
colormap(gray);
imagesc(tmpPGD);
title('PGD-VHL','interpreter','latex','fontsize', fontsz)
ylabel('Number of spikes: $r$','interpreter','latex','fontsize', fontsz)
xlabel('Dimension of subspace: $s$','interpreter','latex','fontsize', fontsz)
set(gca,'YDir','normal','Fontsize',fontsz) % y��̶�����Ϊ��������һ������
set(gca, 'ytick',[2:2:10], 'yticklabel', [2:2:10],'xtick',[2:2:18], 'xticklabel', [2:2:18],'xticklabelmode','auto','yticklabelmode','auto');
cbar = colorbar;
set(cbar,'Ticks',[0:0.2:1])
%ax = gca;
%ax.YDir = 'normal';
hold on
x = 1:0.01:20;
y = 20./x;
plot(x,y,'red','Linewidth', 2);
% save pdf
myfig = gcf;
myfig.PaperUnits = 'inches';
myfig.PaperSize = [6 5.5];
myfig.PaperPosition = [0 0 6 5];
myfig.PaperPositionMode = 'manual';
figname = 'bdft_pgdvhl_withoutsep_withredline';
print( myfig, figname, '-depsc' );
%fprintf('freq err %f\n',hausdorff( fs_rec', fs) );



tmpPGD_sep = zeros(11,18);
for i = 1 : 11
    tmpPGD_sep(i,:) = empir_probs_mat_pgd_bdft_withsep(i,:);
end

figure(2)
colormap(gray);
imagesc(tmpPGD_sep);
title('PGD-VHL with sep','interpreter','latex','fontsize', fontsz)
ylabel('Number of spikes: $r$','interpreter','latex','fontsize', fontsz)
xlabel('Dimension of subspace: $s$','interpreter','latex','fontsize', fontsz)
set(gca,'YDir','normal','Fontsize',fontsz) % y��̶�����Ϊ��������һ������
set(gca, 'ytick',[2:2:10], 'yticklabel', [2:2:10],'xtick',[2:2:18], 'xticklabel', [2:2:18],'xticklabelmode','auto','yticklabelmode','auto');
cbar = colorbar;
set(cbar,'Ticks',[0:0.2:1])
%ax = gca;
%ax.YDir = 'normal';
hold on 
x = 1:0.01:20;
y = 20./x;
plot(x,y,'red','Linewidth', 2);
% save pdf
myfig = gcf;
myfig.PaperUnits = 'inches';
myfig.PaperSize = [6 5.5];
myfig.PaperPosition = [0 0 6 5];
myfig.PaperPositionMode = 'manual';
figname = 'bdft_pgdvhl_withsep_withredline';
print( myfig, figname, '-depsc' );
%fprintf('freq err %f\n',hausdorff( fs_rec', fs) );


tmpPGD = empir_probs_mat_pgd_bdft_withoutsep;

figure(1)
colormap(gray);
imagesc(tmpPGD);
title('PGD','interpreter','latex','fontsize', fontsz)
ylabel('Number of spikes: $r$','interpreter','latex','fontsize', fontsz)
xlabel('Dimension of subspace: $s$','interpreter','latex','fontsize', fontsz)
set(gca,'YDir','normal','Fontsize',fontsz) % y��̶�����Ϊ��������һ������
set(gca, 'ytick',[2:2:10], 'yticklabel', [2:2:10],'xtick',[2:2:18], 'xticklabel', [2:2:18],'xticklabelmode','auto','yticklabelmode','auto');
cbar = colorbar;
set(cbar,'Ticks',[0:0.2:1])
%ax = gca;
%ax.YDir = 'normal';
%hold on
%x = 1:0.01:20;
%y = 20./x;
%plot(x,y,'red','Linewidth', 1.5);
% save pdf
myfig = gcf;
myfig.PaperUnits = 'inches';
myfig.PaperSize = [6 5.5];
myfig.PaperPosition = [0 0 6 5];
myfig.PaperPositionMode = 'manual';
figname = 'bdft_pgd_withoutsep_noredline';
print( myfig, figname, '-depsc' );
%fprintf('freq err %f\n',hausdorff( fs_rec', fs) );

tmpANM = zeros(11,18);
for i = 1 : 11
    tmpANM(i,:) = empir_probs_mat_anm_bdft_withoutsep(i,:);
end

figure(1)
colormap(gray);
imagesc(tmpANM);
title('ANM','interpreter','latex','fontsize', fontsz)
ylabel('Number of spikes: $r$','interpreter','latex','fontsize', fontsz)
xlabel('Dimension of subspace: $s$','interpreter','latex','fontsize', fontsz)
set(gca,'YDir','normal','Fontsize',fontsz) % y��̶�����Ϊ��������һ������
set(gca, 'ytick',[2:2:10], 'yticklabel', [2:2:10],'xtick',[2:2:18], 'xticklabel', [2:2:18],'xticklabelmode','auto','yticklabelmode','auto');
cbar = colorbar;
set(cbar,'Ticks',[0:0.2:1])
%ax = gca;
%ax.YDir = 'normal';
hold on
x = 1:0.01:20;
y = 20./x;
plot(x,y,'red','Linewidth', 2);
% save pdf
myfig = gcf;
myfig.PaperUnits = 'inches';
myfig.PaperSize = [6 5.5];
myfig.PaperPosition = [0 0 6 5];
myfig.PaperPositionMode = 'manual';
figname = 'bdft_anm_withoutsep_withredline_2';
print( myfig, figname, '-depsc' );
%fprintf('freq err %f\n',hausdorff( fs_rec', fs) );

tmpHankel = zeros(11,18);
for i = 1 : 11
    tmpHankel(i,:) = empir_probs_mat_hankel_bdft_withoutsep(i,:);
end

figure(1)
colormap(gray);
imagesc(tmpHankel);
title('VHL','interpreter','latex','fontsize', fontsz)
ylabel('Number of spikes: $r$','interpreter','latex','fontsize', fontsz)
xlabel('Dimension of subspace: $s$','interpreter','latex','fontsize', fontsz)
set(gca,'YDir','normal','Fontsize',fontsz) % y��̶�����Ϊ��������һ������
set(gca, 'ytick',[2:2:10], 'yticklabel', [2:2:10],'xtick',[2:2:18], 'xticklabel', [2:2:18],'xticklabelmode','auto','yticklabelmode','auto');
cbar = colorbar;
set(cbar,'Ticks',[0:0.2:1])
%ax = gca;
%ax.YDir = 'normal';
hold on
x = 1:0.01:20;
y = 20./x;
plot(x,y,'red','Linewidth', 2);
% save pdf
myfig = gcf;
myfig.PaperUnits = 'inches';
myfig.PaperSize = [6 5.5];
myfig.PaperPosition = [0 0 6 5];
myfig.PaperPositionMode = 'manual';
figname = 'bdft_vhl_withoutsep_withredline_2';
print( myfig, figname, '-depsc' );
%fprintf('freq err %f\n',hausdorff( fs_rec', fs) );