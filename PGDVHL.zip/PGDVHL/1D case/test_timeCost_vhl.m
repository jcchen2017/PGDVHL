% VHL
avg_times = 10;
n1 = 128; %n1 = 512; % n=54, 128, 256

s = 3;
r = 3;
time_cost_VHL =zeros(avg_times,1);
err_VHL = zeros(avg_times,1);

for ii = 1:avg_times
    [fs1, ~, ~, ~, X01, B1, y1] = getSignals_bdft_withsep(r, s, n1);
    
    tic;
    X_vhl = solverHankel(y1, B1);
    t_vhl = toc;
    time_cost_VHL(ii) = t_vhl;
    err_vhl1 = norm(X_vhl(:) - X01(:))/norm(X01(:));

    err_VHL(ii,1) = norm(X_anm1(:) - X01(:))/norm(X01(:));
    
    
    fprintf('VHL Time: %f\t Error: %f\n', t_anm1, err_VHL(ii));
end

    
