% PGD-VHL
clear all;clc

avg_times = 10;
n1 = 1024; %n1 = 512; % n=54, 128, 256

s = 3;
r = 3;
time_cost =zeros(avg_times,1);
 
for ii = 1:avg_times
    [fs1, ~, ~, ~, X01, B1, y1] = getSignals_bdft_withsep(r, s, n1);
    
    tic;
    [~,~,~,~,~,~,~,~,~,cond1,err1] = solverPgd(y1,B1,n1,r,s,5000,1/4,1e-7,1e-5,0,1,X01);
    t_pgd1 = toc;
    time_cost(ii,1) = t_pgd1;
     
    
    fprintf('pgd: %f\n');

    
end
mean(time_cost)