N1 = 13;
N2 = 9;
% r number of complex exponentials
r = 4;
% s dimension of subspace, which is less than N
s = 4;

[fs1, fs2, cs, H, ~, ~, X0, B, ~] = getSignals_ofdm(r, s, N1, N2);

% load('fs.mat'); 
% load('cs.mat');
% load('H.mat');
% load('B.mat');
% load('y.mat');
% load('X0.mat');

fs1 = sort(fs1);
fs2 = sort(fs2);
A1 = exp(-1i*2*pi*fs1.* (0:1:N1-1));
A2 = exp(-1i*2*pi*fs2.* (0:1:N2-1));

X0 = zeros(s, N1*N2);

for nn = 1:N2
    CsA2 = diag(cs.*A2(:,nn)); %r x r diag matrix
    X0(:,(nn-1)*N1+1:nn*N1) = H * CsA2 * A1;
end

y = zeros(N1*N2,1);

for i = 1:N1*N2
    y(i,1) =  B(i,:) * X0(:,i);
end

%% solve by PGD-VHL (2D)
tic;
[si,iter,X,ratio,fv,mg,step,~,~,cond,~] = solverPgd2d(y,B,N1,N2,r,s,5000,1/4,1e-7,1e-5,0,1,X0);
t_pgd = toc;
err_pgd = norm(X(:)-X0(:))/norm(X0(:));

freq = music_2d(X,s,r,N1,N2);

fs1_rec = sort(freq(1,:));
fs2_rec = sort(freq(2,:));

%% recover rotations Hs
A_linSytem = zeros(N1*N2, s*r);
for jj = 1:N2
    A_rec = diag(exp(-1i*2*pi*fs2_rec'.* (jj-1)))*exp(-1i*2*pi*fs1_rec'.* (0:1:N1-1));
    for kk = 1:N1
        A_linSytem((jj-1)*N1+kk,:) = kron(A_rec(:,kk).', B((jj-1)*N1+kk,:));
    end
end


Hs_ds = pinv(A_linSytem)*y;

amp = zeros(r,1);
Hs_rec= zeros(s,r);
for jj = 1:r
    idx = (jj-1)*s+1:jj*s;
    tmp = Hs_ds(idx);
    amp(jj) = norm(tmp);
    Hs_rec(:,jj) = tmp/norm( tmp);
    fprintf('Inner : %f\n', abs(Hs_rec(:,jj)'*H(:,jj)));
end

figure
h1=stem3(fs1,fs2,abs(cs),'k-.+','LineWidth',2,'MarkerSize',6);
hold on
h2=stem3(fs1_rec',fs2_rec',amp,'r-.o','LineWidth',2,'MarkerSize',8);
axis([0,1,0,1,0,10]);
l0=legend('Original','PGD-VHL (2D)');

set(l0,'Location','north');

xlabel('$\phi$','interpreter','latex');
ylabel('$\psi$','interpreter','latex');
zlabel('magnitude');

set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'inches');
set(gcf, 'PaperPosition', [0 0 8 6]);
set(gca,'FontName','times new roman','FontSize',25 ,'Layer','top','LineWidth',3);
print('-depsc','MUSIC_2D.eps');



