%%%%Iteration%%%%
n11 = 23;
n12 = 19;
s = 3;
r = 3;
[~, ~, ~, ~, ~, ~, X01, B1, y1] = getSignals2D(r, s, n11, n12);
[~,~,~,~,~,~,~,~,~,cond1,err1] = solverPgd2d_test(y1,B1,n11,n12,r,s,500,1/4,0,1,X01);

n21 = 33;
n22 = 29;
s = 3;
r = 3;
[~, ~, ~, ~, ~, ~, X02, B2, y2] = getSignals2D(r, s, n21, n22);
[~,~,~,~,~,~,~,~,~,cond2,err2] = solverPgd2d_test(y2,B2,n21,n22,r,s,500,1/4,1,1,X02);

n31 = 53;
n32 = 49;
s = 3;
r = 3;
[~, ~, ~, ~, ~, ~, X03, B3, y3] = getSignals2D(r, s, n31, n32);
[~,~,~,~,~,~,~,~,~,cond3,err3] = solverPgd2d_test(y3,B3,n31,n32,r,s,500,1/4,0,1,X03);

it = 1:1:500;
fontsz = 18;
plot(it,log(err1),'-','LineWidth', 1.5, 'Color', [240, 183, 26]/255);
hold on
plot(it,log(err2),'--','LineWidth', 1.5, 'Color', [242, 47, 12]/255);
plot(it,log(err3),'-.','LineWidth', 1.5,'Color', [50, 12, 242]/255);

grid on
set(gca,'ytick',[-32:4:0],'xtick',[0:50:500])
title('Convergence rate','interpreter','latex','fontsize', fontsz);
xlabel('Iteration','interpreter','latex','fontsize', fontsz);
ylabel('Log of reconstruction error','interpreter','latex','fontsize', fontsz);
legend({'$n_1=23,n_2=19$','$n_1=33,n_2=29$','$n_1=53,n_2=49$'},'interpreter','latex','FontSize',14);

% save pdf
myfig = gcf;
myfig.PaperUnits = 'inches';
myfig.PaperSize = [6 5.5];
myfig.PaperPosition = [0 0 6 5];
myfig.PaperPositionMode = 'manual';
figname = 'convergence_rate_2d';
print( myfig, figname, '-depsc' );



